package com.creativosoft;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

class StudentDatabase {
    // Attributes.
    private ArrayList<Student> students;
    private static StudentDatabase studentDatabase;
    private File file;
    private ObjectMapper objectMapper;

    // Methods.
    // Constructor.
    private StudentDatabase() {
        this.students = new ArrayList<>();
        this.file = new File("Student_Database.json");
        this.objectMapper = new ObjectMapper();
        this.objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        readStudents();
    }

    // Getter.
    static StudentDatabase getInstance() {
        if (studentDatabase == null) {
            studentDatabase = new StudentDatabase();
        }
        return studentDatabase;
    }

    // Method to add student.
    void addStudent(Student student) {
        students.add(student);
        saveStudents();
    }

    // Method to remove student.
    void removeStudent(Student student) {
        students.remove(student);
        System.out.println(student.getFirstName().toLowerCase() + " " + student.getLastName().toLowerCase() + " removed.");
        saveStudents();
    }

    // Print all students.
    void printStudents() {
        for (Student student : students) {
                System.out.println(student.toString());
        }
    }

    // Private method to save data to json.
    private void saveStudents() {
        try {
            objectMapper.writeValue(file, students);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Private method to read data from json.
    private void readStudents() {
        ObjectReader objectReader = objectMapper.reader().forType(new TypeReference<ArrayList<Student>>(){});
        try {
            this.students = objectReader.readValue(file);
        } catch (IOException e) {
            System.out.println("No student record to read, exiting program...");
        }

    }

    // Getter for students.
    ArrayList<Student> getStudents() {
        return students;
    }
}
